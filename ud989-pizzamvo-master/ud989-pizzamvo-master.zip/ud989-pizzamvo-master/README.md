# Udacity Pizza App

This is an example from Udacity's [Javascript Design Patterns course](https://www.udacity.com/course/javascript-design-patterns--ud989) for how to use MV* frameworks.

Clone the repo and open up `index.html` in your browser of choice.
